
"use client";

import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { 
  Key, 
  Plus, 
  ShieldCheck, 
  ExternalLink, 
  AlertCircle,
  Eye,
  EyeOff,
  Trash2,
  Lock
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const services = [
  { name: "OpenAI", status: "Configured", icon: "🧠" },
  { name: "Twitter / X", status: "Not Linked", icon: "🐦" },
  { name: "Gmail", status: "Configured", icon: "✉️" },
  { name: "Slack", status: "Not Linked", icon: "💬" },
  { name: "Discord", status: "Not Linked", icon: "👾" },
];

export default function ApiVault() {
  const [showKey, setShowKey] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Lock className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">API Vault</h1>
          </div>
          <p className="text-muted-foreground">Securely manage your external service keys. All keys are encrypted at rest with AES-256.</p>
        </header>

        <div className="grid gap-6">
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader className="flex flex-row items-center gap-4">
              <ShieldCheck className="h-8 w-8 text-primary" />
              <div>
                <CardTitle className="text-lg">Encryption Active</CardTitle>
                <CardDescription>Your keys are protected by your master account encryption key.</CardDescription>
              </div>
            </CardHeader>
          </Card>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Configured Services</h2>
              <Button size="sm" className="gap-2">
                <Plus className="h-4 w-4" /> Add Service
              </Button>
            </div>

            <div className="grid gap-4">
              {services.map((s) => (
                <Card key={s.name} className="border-border/50 bg-card/30">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 flex items-center justify-center rounded-lg bg-muted text-xl">
                        {s.icon}
                      </div>
                      <div>
                        <div className="font-bold flex items-center gap-2">
                          {s.name}
                          <Badge variant={s.status === "Configured" ? "default" : "secondary"} className="text-[10px] h-4">
                            {s.status}
                          </Badge>
                        </div>
                        {s.status === "Configured" ? (
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                            <span className="font-code">sk-••••••••••••4j9w</span>
                            <button 
                              onClick={() => setShowKey(showKey === s.name ? null : s.name)}
                              className="hover:text-primary"
                            >
                              {showKey === s.name ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                            </button>
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground mt-1 italic">Click to connect this service</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card className="border-yellow-500/20 bg-yellow-500/5">
            <CardContent className="p-4 flex gap-4">
              <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0" />
              <div className="text-sm">
                <p className="font-bold text-yellow-500">Important Security Notice</p>
                <p className="text-muted-foreground mt-1">
                  Never share your master password or API keys with anyone. FlowMind employees will never ask for your keys. 
                  We recommend rotating your keys every 90 days for maximum security.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
