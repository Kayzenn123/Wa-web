import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Server-side bash command executor.
 * Limited to development environments for security.
 */
export async function POST(req: NextRequest) {
  try {
    const { command } = await req.json();

    if (!command) {
      return NextResponse.json({ error: 'Command is required' }, { status: 400 });
    }

    // Security: Basic restriction for production-like builds
    if (process.env.NODE_ENV === 'production') {
      return NextResponse.json({ output: 'Execution forbidden in production.' }, { status: 403 });
    }

    const { stdout, stderr } = await execAsync(command);
    return NextResponse.json({ output: stdout || stderr });

  } catch (error: any) {
    return NextResponse.json({ output: `Error: ${error.message}` }, { status: 500 });
  }
}
