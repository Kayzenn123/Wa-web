
"use client";

import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Play, 
  Clock, 
  CheckCircle2, 
  Zap,
  Trash2,
  Copy,
  ExternalLink,
  Loader2
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Card, CardContent } from "@/components/ui/card";
import { ExecutionStats } from "@/components/dashboard/ExecutionStats";
import Link from "next/link";
import { useCollection, useFirestore } from "@/firebase";
import { collection, deleteDoc, doc, orderBy, query } from "firebase/firestore";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { useMemo } from "react";

export default function Dashboard() {
  const db = useFirestore();
  
  const workflowsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'workflows'), orderBy('updatedAt', 'desc'));
  }, [db]);

  const { data: workflows, loading } = useCollection(workflowsQuery);

  const handleDelete = async (id: string) => {
    if (!db) return;
    const docRef = doc(db, 'workflows', id);
    
    deleteDoc(docRef)
      .catch(async () => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'delete',
        }));
      });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <header className="flex flex-col gap-4 mb-8 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Automation Engine</h1>
            <p className="text-muted-foreground">Manage and monitor your active DAG pipelines.</p>
          </div>
          <Link href="/builder/new">
            <Button className="gap-2 shadow-lg shadow-primary/20">
              <Plus className="h-4 w-4" /> New Workflow
            </Button>
          </Link>
        </header>

        <div className="grid gap-8">
          <ExecutionStats />

          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Workflow Library</h2>
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search workflows..." className="pl-9 h-9 bg-card/50" />
              </div>
            </div>

            <div className="grid gap-4">
              {loading ? (
                <div className="flex items-center justify-center p-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : workflows?.length === 0 ? (
                <div className="text-center py-20 border rounded-xl bg-card/30 border-dashed">
                  <p className="text-muted-foreground">No workflows found. Build your first DAG!</p>
                </div>
              ) : (
                workflows?.map((w) => (
                  <Card key={w.id} className="group border-border/50 bg-card/30 hover:border-primary/30 transition-all duration-300">
                    <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-muted/50 transition-colors group-hover:bg-primary/10 text-primary">
                          <Zap className="h-6 w-6" />
                        </div>
                        <div>
                          <Link href={`/builder/${w.id}`} className="font-bold text-lg hover:underline decoration-primary">
                            {w.name}
                          </Link>
                          <div className="flex items-center gap-4 text-[10px] uppercase tracking-wider text-muted-foreground mt-1">
                            <span className="flex items-center gap-1 font-bold">
                              <Clock className="h-3 w-3" /> 
                              {w.updatedAt?.seconds ? new Date(w.updatedAt.seconds * 1000).toLocaleDateString() : 'Just now'}
                            </span>
                            <span className="flex items-center gap-1 text-green-500 font-bold">
                              <CheckCircle2 className="h-3 w-3" /> {w.isActive ? 'Active' : 'Draft'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {w.webhookPath && (
                          <Badge variant="outline" className="text-[10px] py-0 px-2">
                            /{w.webhookPath}
                          </Badge>
                        )}
                        <div className="h-4 w-[1px] bg-border mx-2" />
                        <Link href={`/builder/${w.id}`}>
                          <Button variant="ghost" size="icon" className="h-9 w-9 hover:bg-primary/10 hover:text-primary">
                            <Play className="h-4 w-4" />
                          </Button>
                        </Link>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-9 w-9">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuItem asChild>
                              <Link href={`/builder/${w.id}`} className="flex items-center gap-2">
                                <ExternalLink className="h-4 w-4" /> Open Editor
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 text-destructive focus:text-destructive"
                              onClick={() => handleDelete(w.id)}
                            >
                              <Trash2 className="h-4 w-4" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
