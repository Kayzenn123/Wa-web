
"use client";

import { useState, useEffect, useMemo } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  Save, 
  Terminal,
  Zap,
  Sparkles,
  Loader2,
  Globe,
  Activity
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Canvas } from "@/components/builder/Canvas";
import { draftAIWorkflow, AIWorkflowDraftingOutput } from "@/ai/flows/ai-workflow-drafting";
import { useToast } from "@/hooks/use-toast";
import { executeWorkflow } from "@/lib/workflow-engine";
import { useFirestore, useDoc } from "@/firebase";
import { doc, setDoc, serverTimestamp, collection, addDoc } from "firebase/firestore";
import { useParams, useRouter } from "next/navigation";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Textarea } from "@/components/ui/textarea";

export default function BuilderPage() {
  const { id } = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const db = useFirestore();
  
  const workflowDocRef = useMemo(() => {
    if (!db || !id || id === 'new') return null;
    return doc(db, 'workflows', id as string);
  }, [db, id]);

  const { data: savedWorkflow, loading: loadingWorkflow } = useDoc(workflowDocRef);

  const [workflow, setWorkflow] = useState<AIWorkflowDraftingOutput | null>(null);
  const [prompt, setPrompt] = useState("");
  const [mockPayload, setMockPayload] = useState('{\n  "from": "whatsapp:+62812345678",\n  "body": "Berapa harga Bitcoin hari ini?"\n}');
  const [isLoading, setIsLoading] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executingNodeId, setExecutingNodeId] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [workflowName, setWorkflowName] = useState("");
  const [webhookPath, setWebhookPath] = useState("");

  useEffect(() => {
    if (savedWorkflow) {
      setWorkflow({
        nodes: savedWorkflow.nodes || [],
        edges: savedWorkflow.edges || []
      });
      setWorkflowName(savedWorkflow.name || "");
      setWebhookPath(savedWorkflow.webhookPath || "");
      setLogs(prev => [...prev, `[System] Loaded DAG: ${savedWorkflow.name}`]);
    }
  }, [savedWorkflow]);

  const handleDraft = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setLogs(prev => [...prev, `[AI] Architecting DAG structures...`]);
    try {
      const result = await draftAIWorkflow({ description: prompt });
      setWorkflow(result);
      setLogs(prev => [...prev, `[AI] Blueprint generated with ${result.nodes.length} nodes.`]);
    } catch (error) {
      toast({ variant: "destructive", title: "GenAI Error", description: "Failed to architect workflow." });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!db || !workflow) return;
    const workflowId = (id === 'new' || !id) ? `wf_${Date.now()}` : id as string;
    const docRef = doc(db, 'workflows', workflowId);
    
    const data = {
      name: workflowName || "Untitled Script",
      webhookPath: webhookPath || workflowId,
      nodes: workflow.nodes,
      edges: workflow.edges,
      userId: "system_user",
      isActive: true,
      updatedAt: serverTimestamp(),
      createdAt: savedWorkflow?.createdAt || serverTimestamp()
    };

    setDoc(docRef, data, { merge: true })
      .then(() => {
        toast({ title: "Sync Successful", description: "Workflow state saved to cloud." });
        if (id === 'new') router.push(`/builder/${workflowId}`);
      })
      .catch(async () => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: data,
        }));
      });
  };

  const handleExecute = async () => {
    if (!workflow || !db) return;
    setIsExecuting(true);
    setLogs([]);
    setLogs(prev => [...prev, "[Engine] Preparing Sandbox Environment..."]);
    
    let initialPayload = {};
    try {
      initialPayload = JSON.parse(mockPayload);
    } catch (e) {
      toast({ variant: "destructive", title: "JSON Error", description: "Invalid mock trigger data." });
      setIsExecuting(false);
      return;
    }

    try {
      // Initialize Execution Log in Firestore
      const execRef = await addDoc(collection(db, 'executions'), {
        workflowId: id === 'new' ? 'sandbox' : id,
        status: 'pending',
        startedAt: serverTimestamp(),
        logs: ["[System] Manual dry-run started."]
      });

      await executeWorkflow(
        workflow.nodes as any,
        workflow.edges,
        {
          executionId: execRef.id,
          db: db,
          onNodeStart: (nodeId) => setExecutingNodeId(nodeId),
          onNodeComplete: (nodeId) => {
            setLogs(prev => [...prev, `[Event] Node ${nodeId} execution finalized.`]);
          },
          onLog: (msg) => setLogs(prev => [...prev, msg])
        },
        initialPayload
      );
      
      toast({ title: "Run Complete", description: "DAG reached terminal state successfully." });
    } catch (error: any) {
      setLogs(prev => [...prev, `[Runtime Error] ${error.message}`]);
    } finally {
      setIsExecuting(false);
      setExecutingNodeId(null);
    }
  };

  if (loadingWorkflow) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin text-primary" /></div>;

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      <Navbar />
      
      <div className="flex h-12 items-center justify-between border-b bg-card/40 px-4">
        <div className="flex items-center gap-4">
          <Input 
            placeholder="Workflow Name" 
            className="h-8 w-64 border-none bg-transparent font-bold text-lg"
            value={workflowName}
            onChange={(e) => setWorkflowName(e.target.value)}
          />
          <div className="flex items-center gap-2 border-l pl-4">
            <Globe className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">/api/webhook/</span>
            <Input 
              placeholder="path" 
              className="h-8 w-40 border-none bg-transparent text-xs font-mono"
              value={webhookPath}
              onChange={(e) => setWebhookPath(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExecute} disabled={!workflow || isExecuting}>
            {isExecuting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4 fill-current mr-2" />}
            Test Run
          </Button>
          <Button size="sm" onClick={handleSave} disabled={!workflow}>
            <Save className="h-4 w-4 mr-2" /> Save Script
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <aside className="flex w-80 flex-col border-r bg-card/20 p-4">
          <div className="space-y-6 flex flex-col h-full overflow-y-auto custom-scrollbar pr-2">
            <div className="space-y-3">
              <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Sparkles className="h-3 w-3 text-primary" /> AI Architect
              </label>
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[100px] w-full rounded-xl border bg-background/50 p-3 text-xs focus:ring-1 focus:ring-primary"
                placeholder="E.g. Build a WhatsApp bot that uses AI to answer questions..."
              />
              <Button onClick={handleDraft} disabled={isLoading || !prompt} className="w-full text-xs shadow-lg shadow-primary/20">
                {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 mr-2" />}
                Draft Workflow
              </Button>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Zap className="h-3 w-3 text-green-500" /> Mock Trigger Data
              </label>
              <Textarea 
                value={mockPayload}
                onChange={(e) => setMockPayload(e.target.value)}
                className="min-h-[120px] font-code text-[10px] bg-black/20"
              />
            </div>

            <div className="flex flex-1 flex-col rounded-xl border bg-black/40 overflow-hidden min-h-[200px]">
              <div className="border-b bg-muted/30 px-3 py-2 text-[10px] font-bold uppercase flex items-center justify-between">
                <span className="flex items-center gap-2"><Terminal className="h-3 w-3" /> Runner Console</span>
                {isExecuting && <Activity className="h-3 w-3 animate-pulse text-primary" />}
              </div>
              <div className="flex-1 p-3 font-code text-[10px] leading-relaxed overflow-y-auto custom-scrollbar text-green-500/80">
                {logs.length === 0 ? (
                  <div className="text-muted-foreground italic">Engine Idle...</div>
                ) : (
                  logs.map((log, i) => (
                    <div key={i} className="mb-1">
                      <span className="text-muted-foreground mr-2">{i+1}</span>
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </aside>

        <main className="flex-1 relative bg-background grid-background">
          <Canvas nodes={workflow?.nodes || []} edges={workflow?.edges || []} executingNodeId={executingNodeId} />
        </main>
      </div>
    </div>
  );
}
