
'use client';

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { firebaseConfig } from './config';

export function initializeFirebase() {
  // Ensure we have a valid-looking API key to prevent SDK crashes during development
  const isConfigValid = firebaseConfig.apiKey && !firebaseConfig.apiKey.includes('undefined');
  
  const app = getApps().length === 0 
    ? initializeApp(isConfigValid ? firebaseConfig : { ...firebaseConfig, apiKey: "AIzaSy-placeholder" }) 
    : getApp();
    
  const firestore = getFirestore(app);
  const auth = getAuth(app);

  return { app, firestore, auth };
}

export * from './provider';
export * from './client-provider';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './auth/use-user';
