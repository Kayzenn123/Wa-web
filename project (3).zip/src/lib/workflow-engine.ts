
'use client';

import { Firestore, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export interface Node {
  id: string;
  type: string;
  data: {
    label?: string;
    config?: Record<string, any>;
    [key: string]: any;
  };
}

export interface Edge {
  id: string;
  source: string;
  target: string;
}

export interface ExecutionContext {
  executionId?: string;
  db?: Firestore;
  onNodeStart?: (nodeId: string) => void;
  onNodeComplete?: (nodeId: string, result: any) => void;
  onLog?: (message: string) => void;
}

/**
 * Universal Workflow Engine for DAG Execution.
 * Supports variable interpolation {{ node_id.path }} and specialized node types.
 * Works on both client (for test runs) and server (for webhooks).
 */
export async function executeWorkflow(
  nodes: Node[],
  edges: Edge[],
  context: ExecutionContext,
  initialPayload: any = {}
) {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const results: Record<string, any> = { trigger: initialPayload };
  const logs: string[] = [];

  const addLog = (msg: string) => {
    const timestampedMsg = `[${new Date().toLocaleTimeString()}] ${msg}`;
    logs.push(timestampedMsg);
    if (context.onLog) context.onLog(timestampedMsg);
  };

  const execRef = (context.db && context.executionId) 
    ? doc(context.db, 'executions', context.executionId) 
    : null;

  // Magic Parser: Resolves {{ nodeId.key }} or {{ trigger.body.key }}
  const parseVariables = (config: any) => {
    if (!config) return {};
    const stringified = JSON.stringify(config);
    const replaced = stringified.replace(/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/g, (match, path) => {
      const keys = path.split('.');
      let current: any = results;
      
      for (const key of keys) {
        if (current && typeof current === 'object' && key in current) {
          current = current[key];
        } else {
          return match; 
        }
      }
      return typeof current === 'string' ? current : JSON.stringify(current);
    });
    return JSON.parse(replaced);
  };

  try {
    if (execRef) {
      updateDoc(execRef, { 
        status: 'running', 
        startedAt: serverTimestamp() 
      }).catch(() => {});
    }

    const targets = new Set(edges.map(e => e.target));
    const queue = nodes.filter(n => !targets.has(n.id)).map(n => n.id);
    const executed = new Set<string>();

    addLog(`🚀 Engine started with ${nodes.length} nodes.`);

    while (queue.length > 0) {
      const currentId = queue.shift()!;
      if (executed.has(currentId)) continue;

      const dependencies = edges.filter(e => e.target === currentId).map(e => e.source);
      if (!dependencies.every(d => executed.has(d))) {
        continue;
      }

      const currentNode = nodeMap.get(currentId)!;
      if (context.onNodeStart) context.onNodeStart(currentId);
      addLog(`Executing: ${currentNode.data.label || currentId} [${currentNode.type}]`);

      const resolvedConfig = parseVariables(currentNode.data.config || currentNode.data);
      let nodeResult: any = null;

      switch (currentNode.type) {
        case 'webhook':
        case 'input':
          nodeResult = results.trigger;
          break;

        case 'gemini':
          addLog("Calling Google Gemini 1.5 Flash...");
          try {
            const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
            const geminiResponse = await fetch(
              `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  contents: [{
                    parts: [{
                      text: `System: Kamu adalah Junior Frontend Engineer berbakat yang melayani Bos kamu (seorang Senior Dev). Jawab dengan padat, to the point, teknis, dan prioritaskan blok kode bersih tanpa basa-basi.\n\nUser: ${resolvedConfig.prompt || "Hello"}`
                    }]
                  }]
                })
              }
            );
            const geminiData = await geminiResponse.json();
            if (geminiData.error) throw new Error(geminiData.error.message);
            nodeResult = { reply: geminiData.candidates[0].content.parts[0].text || "No response" };
          } catch (e: any) {
            addLog(`Gemini Error: ${e.message}`);
            nodeResult = { reply: "Error contact Gemini: " + e.message };
          }
          break;

        case 'bashCommand':
          addLog(`Bash execution: ${resolvedConfig.command}`);
          try {
            const baseUrl = typeof window !== 'undefined' ? '' : process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
            const res = await fetch(`${baseUrl}/api/execute/bash`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ command: resolvedConfig.command })
            });
            nodeResult = await res.json();
          } catch (e: any) {
            nodeResult = { output: `Error: ${e.message}` };
          }
          break;

        case 'whatsappSend':
          addLog(`WA Route: ${resolvedConfig.to}`);
          try {
            const waResponse = await fetch('http://localhost:5001/send-message', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                to: resolvedConfig.to,
                message: resolvedConfig.message
              })
            });
            nodeResult = await waResponse.json();
          } catch (e: any) {
            nodeResult = { status: 'bridge_offline', error: e.message };
          }
          break;

        case 'http_request':
        case 'httpRequest':
          const response = await fetch(resolvedConfig.url, {
            method: resolvedConfig.method || 'GET',
            headers: resolvedConfig.headers,
            body: resolvedConfig.body ? JSON.stringify(resolvedConfig.body) : undefined
          });
          nodeResult = await response.json();
          break;

        case 'ifCondition':
          const isTrue = resolvedConfig.leftValue === resolvedConfig.rightValue;
          nodeResult = { conditionMet: isTrue };
          break;

        default:
          addLog(`Pass-through for ${currentNode.type}`);
          nodeResult = resolvedConfig;
      }

      results[currentId] = nodeResult;
      executed.add(currentId);
      if (context.onNodeComplete) context.onNodeComplete(currentId, nodeResult);

      const nextEdges = edges.filter(e => e.source === currentId);
      for (const edge of nextEdges) {
        queue.push(edge.target);
      }
    }

    if (execRef) {
      updateDoc(execRef, { 
        status: 'success', 
        finishedAt: serverTimestamp(),
        graphLog: { results, logs }
      }).catch(() => {});
    }

  } catch (err: any) {
    addLog(`❌ Fatal: ${err.message}`);
    if (execRef) {
      updateDoc(execRef, { 
        status: 'failed', 
        finishedAt: serverTimestamp(),
        graphLog: { error: err.message, logs, results }
      }).catch(() => {});
    }
    throw err;
  }

  return results;
}

export class WorkflowEngine {
  private nodes: Node[];
  private edges: Edge[];
  private initialPayload: any;

  constructor(nodes: Node[], edges: Edge[], initialPayload: any) {
    this.nodes = nodes;
    this.edges = edges;
    this.initialPayload = initialPayload;
  }

  public async run() {
    return executeWorkflow(this.nodes, this.edges, {}, this.initialPayload);
  }
}
