"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
} from "recharts";
import { Zap, CheckCircle2, AlertCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

const data = [
  { name: "Mon", executions: 400, success: 380, failed: 20 },
  { name: "Tue", executions: 300, success: 270, failed: 30 },
  { name: "Wed", executions: 500, success: 490, failed: 10 },
  { name: "Thu", executions: 280, success: 250, failed: 30 },
  { name: "Fri", executions: 590, success: 550, failed: 40 },
  { name: "Sat", executions: 190, success: 180, failed: 10 },
  { name: "Sun", executions: 430, success: 410, failed: 20 },
];

const stats = [
  { title: "Total Executions", value: "2,690", icon: Zap, color: "text-primary", bg: "bg-primary/10" },
  { title: "Success Rate", value: "96.4%", icon: CheckCircle2, color: "text-green-500", bg: "bg-green-500/10" },
  { title: "Avg. Latency", value: "1.2s", icon: Clock, color: "text-accent", bg: "bg-accent/10" },
  { title: "Active Workflows", value: "12", icon: AlertCircle, color: "text-purple-500", bg: "bg-purple-500/10" },
];

export function ExecutionStats() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="border-border/50 bg-card/30 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                {stat.title}
              </CardTitle>
              <div className={cn("rounded-md p-2", stat.bg)}>
                <stat.icon className={cn("h-4 w-4", stat.color)} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/50 bg-card/30 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Workflow Health (Last 7 Days)</CardTitle>
        </CardHeader>
        <CardContent className="pl-2">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border) / 0.5)" />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(value) => `${value}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    borderColor: 'hsl(var(--border))',
                    borderRadius: '8px'
                  }} 
                  itemStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Bar dataKey="success" stackId="a" fill="hsl(var(--primary))" radius={[0, 0, 0, 0]} barSize={40} />
                <Bar dataKey="failed" stackId="a" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
