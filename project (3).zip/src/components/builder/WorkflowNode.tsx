
"use client";

import { cn } from "@/lib/utils";
import { 
  Workflow, 
  Globe, 
  Mail, 
  Twitter, 
  Filter, 
  Clock, 
  Terminal, 
  ArrowRightLeft,
  Settings2,
  Slack,
  Zap,
  Webhook,
  Brain,
  MessageSquare,
  GitBranch,
  Bot,
  Command,
  Sparkles
} from "lucide-react";

export type NodeType = 
  | 'input' 
  | 'output' 
  | 'ai_processor' 
  | 'openAi'
  | 'gemini'
  | 'aiAgent'
  | 'web_scraper' 
  | 'email_sender' 
  | 'twitter_poster' 
  | 'slackMsg'
  | 'whatsappSend'
  | 'data_filter' 
  | 'condition' 
  | 'ifCondition'
  | 'timer' 
  | 'code_executor' 
  | 'bashCommand'
  | 'http_request'
  | 'httpRequest'
  | 'webhook';

const nodeIcons: Record<string, any> = {
  input: Zap,
  output: Workflow,
  ai_processor: Brain,
  openAi: Brain,
  gemini: Sparkles,
  aiAgent: Bot,
  web_scraper: Globe,
  email_sender: Mail,
  twitter_poster: Twitter,
  slackMsg: Slack,
  whatsappSend: MessageSquare,
  data_filter: Filter,
  condition: GitBranch,
  ifCondition: GitBranch,
  timer: Clock,
  code_executor: Terminal,
  bashCommand: Command,
  http_request: ArrowRightLeft,
  httpRequest: ArrowRightLeft,
  webhook: Webhook,
};

const nodeColors: Record<string, string> = {
  input: "bg-green-500/10 border-green-500/50 text-green-400",
  output: "bg-red-500/10 border-red-500/50 text-red-400",
  ai_processor: "bg-primary/10 border-primary/50 text-primary",
  openAi: "bg-indigo-500/10 border-indigo-500/50 text-indigo-400",
  gemini: "bg-blue-500/10 border-blue-500/50 text-blue-400",
  aiAgent: "bg-primary/10 border-primary/50 text-primary",
  web_scraper: "bg-cyan-500/10 border-cyan-500/50 text-cyan-400",
  email_sender: "bg-amber-500/10 border-amber-500/50 text-amber-400",
  twitter_poster: "bg-sky-500/10 border-sky-500/50 text-sky-400",
  slackMsg: "bg-indigo-500/10 border-indigo-500/50 text-indigo-400",
  whatsappSend: "bg-emerald-500/10 border-emerald-500/50 text-emerald-400",
  data_filter: "bg-purple-500/10 border-purple-500/50 text-purple-400",
  condition: "bg-pink-500/10 border-pink-500/50 text-pink-400",
  ifCondition: "bg-pink-500/10 border-pink-500/50 text-pink-400",
  timer: "bg-indigo-500/10 border-indigo-500/50 text-indigo-400",
  code_executor: "bg-emerald-500/10 border-emerald-500/50 text-emerald-400",
  bashCommand: "bg-slate-700/10 border-slate-500/50 text-slate-200",
  http_request: "bg-slate-500/10 border-slate-500/50 text-slate-400",
  httpRequest: "bg-slate-500/10 border-slate-500/50 text-slate-400",
  webhook: "bg-orange-500/10 border-orange-500/50 text-orange-400",
};

interface WorkflowNodeProps {
  id: string;
  type: string;
  label: string;
  active?: boolean;
  position?: { x: number; y: number };
  config?: Record<string, any>;
}

export function WorkflowNode({ type, label, active, config }: WorkflowNodeProps) {
  const Icon = nodeIcons[type] || Workflow;
  const colorClasses = nodeColors[type] || "bg-muted/10 border-muted/50 text-muted-foreground";

  return (
    <div className={cn(
      "group relative flex w-64 flex-col rounded-xl border bg-card/80 p-0 shadow-xl backdrop-blur-sm transition-all hover:shadow-primary/10",
      active ? "ring-2 ring-primary ring-offset-2 ring-offset-background bioluminescent-pulse" : "hover:border-primary/30"
    )}>
      <div className={cn("flex items-center gap-3 rounded-t-xl border-b p-3", colorClasses)}>
        <Icon className="h-5 w-5" />
        <span className="flex-1 text-sm font-semibold truncate">{label}</span>
        <Settings2 className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer hover:text-foreground" />
      </div>
      
      <div className="flex flex-col gap-2 p-3">
        {config ? (
          <div className="space-y-1">
            {Object.entries(config).slice(0, 3).map(([key, value]) => (
              <div key={key} className="flex justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
                <span>{key}</span>
                <span className="font-code text-foreground truncate max-w-[120px]">{String(value)}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground italic">Configuration idle</p>
        )}
      </div>

      <div className="absolute -left-1.5 top-1/2 flex h-3 w-3 -translate-y-1/2 items-center justify-center rounded-full border bg-background group-hover:border-primary/50 transition-colors">
        <div className="h-1 w-1 rounded-full bg-muted-foreground group-hover:bg-primary transition-colors" />
      </div>
      <div className="absolute -right-1.5 top-1/2 flex h-3 w-3 -translate-y-1/2 items-center justify-center rounded-full border bg-background group-hover:border-primary/50 transition-colors">
        <div className="h-1 w-1 rounded-full bg-muted-foreground group-hover:bg-primary transition-colors" />
      </div>

      {active && (
        <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-1.5 whitespace-nowrap rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-bold text-primary animate-pulse">
          <div className="h-1.5 w-1.5 rounded-full bg-primary" />
          EXECUTING...
        </div>
      )}
    </div>
  );
}
