
"use client";

import { useState } from "react";
import { WorkflowNode, NodeType } from "./WorkflowNode";
import { Button } from "@/components/ui/button";
import { Maximize2, Minimize2, MousePointer2, Hand, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface Node {
  id: string;
  type: NodeType;
  position: { x: number; y: number };
  data: {
    label: string;
    config?: Record<string, any>;
  };
}

interface Edge {
  id: string;
  source: string;
  target: string;
}

interface CanvasProps {
  nodes: Node[];
  edges: Edge[];
  executingNodeId?: string | null;
}

export function Canvas({ nodes, edges, executingNodeId }: CanvasProps) {
  const [zoom, setZoom] = useState(1);
  const [offset] = useState({ x: 0, y: 0 });

  return (
    <div className="relative h-full w-full overflow-hidden bg-background grid-background">
      <div className="absolute bottom-6 left-6 z-10 flex flex-col gap-2">
        <div className="flex items-center gap-2 rounded-lg border bg-background/80 p-1 backdrop-blur-md shadow-lg">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}><Minimize2 className="h-4 w-4" /></Button>
          <span className="text-[10px] font-bold w-12 text-center">{Math.round(zoom * 100)}%</span>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setZoom(z => Math.min(1.5, z + 0.1))}><Maximize2 className="h-4 w-4" /></Button>
        </div>
        <div className="flex items-center gap-2 rounded-lg border bg-background/80 p-1 backdrop-blur-md shadow-lg">
          <Button variant="ghost" size="icon" className="h-8 w-8 bg-primary/10 text-primary"><MousePointer2 className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8"><Hand className="h-4 w-4" /></Button>
          <div className="w-[1px] h-4 bg-border mx-1" />
          <Button variant="ghost" size="icon" className="h-8 w-8"><Plus className="h-4 w-4" /></Button>
        </div>
      </div>

      <div 
        className="relative transition-transform duration-200"
        style={{ 
          transform: `scale(${zoom}) translate(${offset.x}px, ${offset.y}px)`,
          transformOrigin: '0 0'
        }}
      >
        <svg className="absolute inset-0 pointer-events-none" style={{ width: '5000px', height: '5000px' }}>
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="7"
              refX="10"
              refY="3.5"
              orient="auto"
            >
              <polygon points="0 0, 10 3.5, 0 7" fill="currentColor" />
            </marker>
          </defs>
          {edges.map((edge) => {
            const source = nodes.find(n => n.id === edge.source);
            const target = nodes.find(n => n.id === edge.target);
            if (!source || !target) return null;

            const startX = source.position.x + 256; 
            const startY = source.position.y + 40; 
            const endX = target.position.x;
            const endY = target.position.y + 40;

            const midX = startX + (endX - startX) / 2;
            const isActive = executingNodeId === source.id;

            return (
              <path
                key={edge.id}
                d={`M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`}
                fill="none"
                stroke="currentColor"
                strokeWidth={isActive ? "3" : "2"}
                markerEnd="url(#arrowhead)"
                className={cn(
                  "transition-all duration-300 text-border",
                  isActive && "text-primary animate-marching-ants"
                )}
              />
            );
          })}
        </svg>

        {nodes.map((node) => (
          <div 
            key={node.id} 
            className="absolute transition-all duration-300"
            style={{ 
              left: `${node.position.x}px`, 
              top: `${node.position.y}px` 
            }}
          >
            <WorkflowNode 
              id={node.id}
              type={node.type}
              label={node.data.label}
              active={executingNodeId === node.id}
              config={node.data.config}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
